export const authStorage = {
    getAccessToken: () => localStorage.getItem("accessToken"),
    setAccessToken: (token) => localStorage.setItem("accessToken", token),
    getRefreshToken: () => localStorage.getItem("refreshToken"),
    setRefreshToken: (token) => localStorage.setItem("refreshToken", token),
    setUserStorage: (user) => localStorage.setItem("user", JSON.stringify(user)),
    getUserStorage: () => {
        const user = localStorage.getItem("user")
        return user ? JSON.parse(user) : null
    },
    clear: () => localStorage.clear(),
    saveStorage: function(user){
        this.setAccessToken(user.accessToken)
        this.setRefreshToken(user.refreshToken)
        this.setUserStorage(user.user)
    }
}