import { createSlice } from "@reduxjs/toolkit";
import { authStorage } from "./authStorage";
import { loginThunk, registerThunk } from "./authThunk";

const initialState = {
    user: authStorage.getUserStorage() || null,
    loading: false,
    error: null
}

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        clearUser(state) {
            authStorage.clear()
            state.user = null
        },
    },
    extraReducers: (builder) => {
        builder

            //register
            .addCase(registerThunk.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(registerThunk.fulfilled, (state, action) => {
                state.loading = false;
                state.user = action.payload;
            })
            .addCase(registerThunk.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            //login
            .addCase(loginThunk.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(loginThunk.fulfilled, (state, action) => {
                state.loading = false;
                state.user = action.payload;
                authStorage.saveStorage(action.payload)
            })
            .addCase(loginThunk.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            });
    },
});

export const { clearUser } = authSlice.actions;

export default authSlice.reducer;