import { z } from 'zod';

export const authSchema = z.object({
  email: z.string().email('Введите корректный email'),
  password: z.string().min(6, 'Минимальная длина пароля — 6 символов'),
});