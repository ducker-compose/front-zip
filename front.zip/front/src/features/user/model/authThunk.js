import { createAsyncThunk } from "@reduxjs/toolkit"
import { AuthApi } from "../api/authApi"

export const registerThunk = createAsyncThunk(
    "auth/register",
    async (user, { rejectWithValue }) => {
        try {
            const res = await AuthApi.register(user)

            return res
        } catch {
            return rejectWithValue("ошибка регистрации")
        }
    }
)
export const loginThunk = createAsyncThunk(
    "auth/login",
    async (user, { rejectWithValue }) => {
        try {
            const res = await AuthApi.login(user)

            return res
        } catch {
            return rejectWithValue("ошибка входа")
        }
    }
)