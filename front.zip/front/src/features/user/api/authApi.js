import { baseApi } from "../../../shared/lib/baseApi";

export class AuthApi{
    static async register(user){
        const res = await baseApi.post("/auth/register", user)

        return res.data
    }
    static async login(user){
        const res = await baseApi.post("/auth/login", user)

        return res.data
    }
}