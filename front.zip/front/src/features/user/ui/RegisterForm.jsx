import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useDispatch, useSelector } from "react-redux"
import Loader from '../../../shared/ui/loader/Loader';
import { registerThunk } from '../model/authThunk';
import { authSchema } from '../model/authSchems';
import { useNavigate } from 'react-router';
import { useToast } from '../../../shared/lib/toast/toastContext';
import "./index.css"


export default function RegisterForm() {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm({
        resolver: zodResolver(authSchema),
    });

    const dispatch = useDispatch()

    const navigate = useNavigate()

    const { loading } = useSelector(state => state.auth)

    const { showToast } = useToast()

    const onSubmit = async (user) => {

        try {
            await dispatch(registerThunk(user)).unwrap()
            navigate("/login")
            showToast("Успешная регистрация", 'success')
        } catch {
            showToast("ошибка", 'error')
        }
    };

    if (loading) return <Loader />

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <div>
                <label>
                    Email
                    <input {...register('email')} />
                </label>
                {errors.email && <p style={{ color: 'red' }}>{errors.email.message}</p>}
            </div>

            <div>
                <label>
                    Пароль
                    <input {...register('password')} />
                </label>
                {errors.password && <p style={{ color: 'red' }}>{errors.password.message}</p>}
            </div>

            <button type="submit">
                Зарегистрироваться
            </button>
        </form>
    );
}
