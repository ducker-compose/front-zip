import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { authSchema } from '../model/authSchems';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router';
import { loginThunk } from '../model/authThunk';
import Loader from '../../../shared/ui/loader/Loader';
import { useToast } from '../../../shared/lib/toast/toastContext';
import "./index.css"

export default function LoginForm() {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm({
        resolver: zodResolver(authSchema),
    });

    const dispatch = useDispatch()

    const navigate = useNavigate()

    const { loading } = useSelector(state => state.auth)

    const { showToast } = useToast()

    const onSubmit = async (user) => {
        try {
            await dispatch(loginThunk(user)).unwrap()
            navigate("/pakemon")
            showToast("Успешный вход", 'success')
        } catch {
            showToast("ошибка входа", 'error')
        }
    };

    if (loading) return <Loader />

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <div>
                <label>
                    Email
                    <input {...register('email')} />
                </label>
                {errors.email && <p style={{ color: 'red' }}>{errors.email.message}</p>}
            </div>

            <div>
                <label>
                    Пароль
                    <input {...register('password')} />
                </label>
                {errors.password && <p style={{ color: 'red' }}>{errors.password.message}</p>}
            </div>

            <button type="submit">
                Войти
            </button>
        </form>
    );
}
