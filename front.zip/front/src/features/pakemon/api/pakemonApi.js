import { baseApi } from "../../../shared/lib/baseApi";

export class PakemonApi{
    static async getAll(){
        const res = await baseApi.get("/anime")

        return res.data
    }
    static async create(pakemon){
        const res = await baseApi.post("/anime", pakemon)

        return res.data
    }
    static async delete(pakemon){
        await baseApi.delete("/anime/" + pakemon.id)

        return pakemon.id
    }
    static async update(newPakemon, id){
        const res = await baseApi.put("/anime/" + id, newPakemon)

        return res.data
    }
}