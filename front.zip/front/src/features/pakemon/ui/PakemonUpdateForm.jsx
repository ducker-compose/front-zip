import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useDispatch, useSelector } from "react-redux"
import Loader from '../../../shared/ui/loader/Loader';
import { pakemonSchema } from '../model/pakemonSchema';
import { updateThunk } from '../model/pakemonThunk';
import { useToast } from '../../../shared/lib/toast/toastContext';
import "./index.css"

export default function PakemonUpdateForm({ pakemon, id, setShow }) {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(pakemonSchema),
        defaultValues: pakemon
    });

    const dispatch = useDispatch()

    

    const { loading } = useSelector(state => state.pakemon)

    const { showToast } = useToast()

    const onSubmit = async (newPakemon) => {

        try {
            await dispatch(updateThunk({ newPakemon, id })).unwrap()
            setShow(false)
            showToast("Успешно обновлено", 'success')
        } catch {
            showToast("ошибка обновления", 'error')
        }
    };

    if (loading) return <Loader />

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <div>
                <label>
                    имя
                    <input {...register('name')} />
                </label>
                {errors.name && <p style={{ color: 'red' }}>{errors.name.message}</p>}
            </div>

            <div>
                <label>
                    описание
                    <input {...register('description')} />
                </label>
                {errors.description && <p style={{ color: 'red' }}>{errors.description.message}</p>}
            </div>
            <div>
                <label>
                    уровень
                    <input type='number' {...register('level')} />
                </label>
                {errors.level && <p style={{ color: 'red' }}>{errors.level.message}</p>}
            </div>
            <div>
                <label>
                    здоровье
                    <input type='number' {...register('hp')} />
                </label>
                {errors.hp && <p style={{ color: 'red' }}>{errors.hp.message}</p>}
            </div>
            <div>
                <label>
                    атака
                    <input type='number' {...register('attack')} />
                </label>
                {errors.attack && <p style={{ color: 'red' }}>{errors.attack.message}</p>}
            </div>

            <button type="submit">
                Сохранить
            </button>
        </form>
    );
}
