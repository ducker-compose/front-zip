import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useDispatch, useSelector } from "react-redux"
import Loader from '../../../shared/ui/loader/Loader';
import { pakemonSchema } from '../model/pakemonSchema';
import { createThunk } from '../model/pakemonThunk';
import { useToast } from '../../../shared/lib/toast/toastContext';
import "./index.css"

export default function PakemonForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(pakemonSchema),
  });

  const dispatch = useDispatch()

  const {showToast} = useToast()

  const { loading } = useSelector(state => state.pakemon)

  const onSubmit = async (pakemon) => {
    try {
      await dispatch(createThunk(pakemon)).unwrap()
      showToast("Успешно", 'success')
    } catch {
      showToast("ошибка", 'error')
    }
  };

  if (loading) return <Loader />

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <h2>Создайте своего пакемона!</h2>
      <div>
        <label>
          имя
          <input {...register('name')} />
        </label>
        {errors.name && <p style={{ color: 'red' }}>{errors.name.message}</p>}
      </div>

      <div>
        <label>
          описание
          <input {...register('description')} />
        </label>
        {errors.description && <p style={{ color: 'red' }}>{errors.description.message}</p>}
      </div>
      <div>
        <label>
          уровень
          <input type='number' {...register('level')} />
        </label>
        {errors.level && <p style={{ color: 'red' }}>{errors.level.message}</p>}
      </div>
      <div>
        <label>
          здоровье
          <input type='number' {...register('hp')} />
        </label>
        {errors.hp && <p style={{ color: 'red' }}>{errors.hp.message}</p>}
      </div>
      <div>
        <label>
          атака
          <input type='number' {...register('attack')} />
        </label>
        {errors.attack && <p style={{ color: 'red' }}>{errors.attack.message}</p>}
      </div>

      <button type="submit">
        создать
      </button>
    </form>
  );
}
