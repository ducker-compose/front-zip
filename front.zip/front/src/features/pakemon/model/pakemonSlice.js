import { createSlice } from "@reduxjs/toolkit";
import { createThunk, deleteThunk, getAllThunk, updateThunk } from "./pakemonThunk";

const initialState = {
    pakemons: [],
    loading: false,
    error: null
}

const pakemonSlice = createSlice({
    name: 'pakemon',
    initialState,
    reducers: {

    },
    extraReducers: (builder) => {
        builder

            //getAll
            .addCase(getAllThunk.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(getAllThunk.fulfilled, (state, action) => {
                state.loading = false;
                state.pakemons = action.payload;
                
            })
            .addCase(getAllThunk.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            //create
            .addCase(createThunk.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(createThunk.fulfilled, (state, action) => {
                state.loading = false;
                state.pakemons.push(action.payload);
            })
            .addCase(createThunk.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            //delete
            .addCase(deleteThunk.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(deleteThunk.fulfilled, (state, action) => {
                state.loading = false;
                state.pakemons = state.pakemons.filter(el => el.id !== action.payload);
            })
            .addCase(deleteThunk.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })

            //update
            .addCase(updateThunk.pending, (state) => {
                state.loading = true;
                state.error = null;
            })
            .addCase(updateThunk.fulfilled, (state, action) => {
                state.loading = false;
                const index = state.pakemons.findIndex(el => el.id === action.payload.id)
                state.pakemons[index] = action.payload
            })
            .addCase(updateThunk.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload;
            })
    },
});

export default pakemonSlice.reducer;