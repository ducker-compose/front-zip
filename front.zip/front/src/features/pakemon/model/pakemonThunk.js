import { createAsyncThunk } from "@reduxjs/toolkit"
import { PakemonApi } from "../api/pakemonApi"

export const getAllThunk = createAsyncThunk(
    "pakemon/getAll",
    async (_, { rejectWithValue }) => {
        try {
            const res = await PakemonApi.getAll()

            return res
        } catch {
            return rejectWithValue("ошибка получения пакемонов")
        }
    }
)
export const createThunk = createAsyncThunk(
    "pakemon/create",
    async (pakemon, { rejectWithValue }) => {
        try {
            const res = await PakemonApi.create(pakemon)

            return res
        } catch {
            return rejectWithValue("ошибка создания пакемона")
        }
    }
)
export const deleteThunk = createAsyncThunk(
    "pakemon/delete",
    async (pakemon, { rejectWithValue }) => {
        try {
            const res = await PakemonApi.delete(pakemon)

            return res
        } catch {
            return rejectWithValue("ошибка удаления пакемона")
        }
    }
)
export const updateThunk = createAsyncThunk(
    "pakemon/update",
    async ({newPakemon, id}, { rejectWithValue }) => {
        try {
            const res = await PakemonApi.update(newPakemon, id)

            return res
        } catch {
            return rejectWithValue("ошибка изменения пакемонов")
        }
    }
)
