import * as yup from "yup";

export const pakemonSchema = yup.object({
  name: yup.string().required("поле не может быть пустым"),
  description: yup.string().required("поле не может быть пустым"),
  level: yup.number("уровень должно быть числом").required("поле не может быть пустым"),
  hp: yup.number("здоровье должно быть числом").required("поле не может быть пустым"),
  attack: yup.number("атака должна быть числом").required("поле не может быть пустым"),
});