import { configureStore } from '@reduxjs/toolkit';
import authReducer from '../../features/user/model/authSlice';
import pakemonReducer from "../../features/pakemon/model/pakemonSlice"

export const store = configureStore({
  reducer: {
    auth: authReducer,
    pakemon: pakemonReducer
  },
});