import React from 'react'
import Header from '../../widgets/ui/Header'
import { Outlet } from 'react-router'
import "./index.css"

function Layout() {
  return (
    <div className='bady'>
      <header>
        <Header/>
      </header>
      <main>
        <Outlet />
      </main>
    </div>
  )
}

export default Layout