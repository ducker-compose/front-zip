import { createBrowserRouter } from 'react-router'
import Layout from '../layout/Layout'
import RegisterPage from '../../pages/user/register/RegisterPage'
import LoginPage from '../../pages/user/login/LoginPage'
import PakemonPage from '../../pages/pakemon/PakemonPage'

export const router = createBrowserRouter([
    {
        path: "/",
        element: <Layout />,
        children: [
            {
                path: "/register",
                element: <RegisterPage />,
            },
            {
                path: "/login",
                element: <LoginPage />,
            },
            {
                path: "/pakemon",
                element: <PakemonPage />,
            },
        ]
    }
])