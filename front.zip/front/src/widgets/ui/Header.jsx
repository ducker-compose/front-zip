import React from 'react'
import { Link } from 'react-router'

function Header() {

  

  return (
    <nav>
        <Link to={"/register"}>Регистрация</Link>
        <Link to={"/login"}>Авторизация</Link>
        <Link to={"/pakemon"}>Пакемоны</Link>
    </nav>
  )
}

export default Header