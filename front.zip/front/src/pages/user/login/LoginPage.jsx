import React from 'react'
import LoginForm from '../../../features/user/ui/LoginForm'

function LoginPage() {
  return (
    <div>
      <LoginForm/>
    </div>
  )
}

export default LoginPage