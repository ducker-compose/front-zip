import React from 'react'
import RegisterForm from '../../../features/user/ui/RegisterForm'

function RegisterPage() {
  return (
    <div>
        <RegisterForm/>
    </div>
  )
}

export default RegisterPage