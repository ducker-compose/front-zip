import React from 'react'
import PakemonForm from '../../features/pakemon/ui/PakemonForm'
import List from '../../entities/pakemon/ui/List'
import './index.css'

function PakemonPage() {
  return (
    <div className='page'>
        <PakemonForm />
        <List/>
    </div>
  )
}

export default PakemonPage