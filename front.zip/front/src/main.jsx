import { createRoot } from 'react-dom/client'
import './index.css'
import { RouterProvider } from 'react-router'
import { router } from './app/router/router'
import { Provider } from 'react-redux'
import { store } from './app/store/store'
import ToastProvider from './shared/lib/toast/ToastProvider'

createRoot(document.getElementById('root')).render(
  <Provider store={store} >
    <ToastProvider>
      <RouterProvider router={router}/>
    </ToastProvider>
  </Provider>
)
