import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { getAllThunk } from '../../../features/pakemon/model/pakemonThunk';
import Card from './Card';

function List() {

    const dispatch = useDispatch()

    useEffect(() => {

        dispatch(getAllThunk())
        console.log('данные получены');

    }, [dispatch])

    const { pakemons } = useSelector(state => state.pakemon)

    console.log(pakemons);


    return (
        <div className='list'>
            {
                pakemons.map(pakemon => (
                    <Card key={pakemon.id} pakemon={pakemon} />
                ))
            }
        </div>
    )
}

export default List