import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { deleteThunk } from '../../../features/pakemon/model/pakemonThunk'
import PakemonUpdateForm from '../../../features/pakemon/ui/PakemonUpdateForm'
import { authStorage } from '../../../features/user/model/authStorage'
import { useToast } from '../../../shared/lib/toast/toastContext'
import './index.css'

function Card({ pakemon }) {

  const dispatch = useDispatch()

  const [show, setShow] = useState(false)

  const { showToast } = useToast()

  const onDelete = async () => {
    try {
      await dispatch(deleteThunk(pakemon)).unwrap()
      showToast("Успешно удалено", 'success')
    } catch {
      showToast("ошибка удаления", 'error')
    }
  };

  const user = authStorage.getUserStorage()

  const isAuthor = user.id === pakemon.userId

  return (
    <div className='card'>
      <p>{pakemon.name}</p>
      <p>{pakemon.description}</p>
      <p>{pakemon.attack}</p>
      <p>{pakemon.hp}</p>
      <p>{pakemon.level}</p>


      {
        isAuthor && (
          <>
            <button onClick={onDelete}>delete</button>
            <button onClick={() => setShow(!show)}>изменить</button>
          </>
        )
      }

      {
        show && <PakemonUpdateForm setShow={setShow} id={pakemon.id} pakemon={pakemon} />
      }
    </div>
  )
}

export default Card